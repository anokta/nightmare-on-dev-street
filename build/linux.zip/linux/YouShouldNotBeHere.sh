#!/bin/sh
printf '\033c\033]0;%s\a' NightmareOnDevStreet
base_path="$(dirname "$(realpath "$0")")"
"$base_path/YouShouldNotBeHere.x86_64" "$@"
